package com.serotonin.bacnet4j.npdu;

abstract public class NetworkIdentifier {
    abstract public String getIdString();
}
